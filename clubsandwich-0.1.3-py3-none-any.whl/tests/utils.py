import pathlib

fixtures_root = pathlib.Path(__file__).parent.parent